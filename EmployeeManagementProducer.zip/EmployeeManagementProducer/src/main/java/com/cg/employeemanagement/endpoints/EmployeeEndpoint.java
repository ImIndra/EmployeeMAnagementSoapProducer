package com.cg.employeemanagement.endpoints;

import java.io.IOException;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.cg.employeemanagement.model.Employee;
import com.cg.employeemanagement.service.EmployeeService;
import com.capg.employeemanagement.AddEmployeeRequest;
import com.capg.employeemanagement.AddEmployeeResponse;
import com.capg.employeemanagement.ServiceStatus;
import com.capg.employeemanagement.EmployeeInfo;

@Endpoint
public class EmployeeEndpoint {


	private static final String NAMESPACE_URI = "http://www.capgemini.com/employee-ws";
	
	@Autowired
	private EmployeeService employeeService;
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "addEmployeeRequest")
	@ResponsePayload
	public AddEmployeeResponse addArticle(@RequestPayload AddEmployeeRequest request)throws IOException {
		AddEmployeeResponse response = new AddEmployeeResponse();		
    	        ServiceStatus serviceStatus = new ServiceStatus();		
		Employee employee = new Employee();
		employee.setEmpId(request.getEmpId());
		employee.setFirst_name(request.getFirstName());
		employee.setLast_name(request.getLastName());
		employee.setAddress(request.getAddress());
		employeeService.addEmployee(employee);
              /*  boolean flag = articleService.addArticle(article);
                if (flag == false) {
        	   serviceStatus.setStatusCode("CONFLICT");
        	   serviceStatus.setMessage("Content Already Available");
        	   response.setServiceStatus(serviceStatus);
                } else {*/
		  // EmployeeInfo employeeInfo = new EmployeeInfo();
	     //      BeanUtils.copyProperties(employee, employeeInfo);
		  // response.setEmployeeInfo(employeeInfo);
        	   serviceStatus.setStatusCode("SUCCESS");
        	   serviceStatus.setMessage("Content Added Successfully");
        	   response.setServiceStatus(serviceStatus);
                //}
                return response;
	}
	
}