package com.cg.employeemanagement.DAO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Repository;

import com.cg.employeemanagement.model.Employee;

@Repository
public class EmployeeDAO {

	public void addEmployee(Employee employee) throws IOException {
		FileInputStream fis= new FileInputStream(new File("C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
        XSSFSheet sheet = workbook.getSheetAt(0);
        
        Object[][] employeeDetails = {
                
                {employee.getEmpId(), employee.getFirst_name(), employee.getLast_name(),employee.getAddress()}
        };

        int rowNum = sheet.getLastRowNum()+1;
        System.out.println("Creating excel");

        for (Object[] emp : employeeDetails) {
            Row row = sheet.createRow(rowNum);
            int colNum = 0;
            for (Object field : emp) {
                Cell cell = row.createCell(colNum++);
                if (field instanceof String) {
                    cell.setCellValue((String) field);}
            }
        }

        try {
            FileOutputStream outputStream = new FileOutputStream("C:\\Desktop\\STSWorkspace\\EmployeeManagementProducer\\src\\main\\resources\\Database.xlsx");
            workbook.write(outputStream);
            workbook.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Done");
    }
		
	}

