package com.cg.employeemanagement.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeemanagement.DAO.EmployeeDAO;
import com.cg.employeemanagement.model.Employee;


@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeDAO employeeDAO;

	public void deleteEmployee(long id) {
		// TODO Auto-generated method stub
		
	}

	public void addEmployee(Employee employee) throws IOException {
		employeeDAO.addEmployee(employee);
		
		// TODO Auto-generated method stub
		
	}

}
